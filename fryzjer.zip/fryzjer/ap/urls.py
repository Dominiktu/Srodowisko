from django.urls import path
from . import views,logowanie,rezerwacja
urlpatterns =[
    path('',views.tm, name='tm'),
    path('Strona_glowna',views.strona_glowna, name='strona_glowna'),
    path('wyloguj', views.wyloguj , name='wyloguj'),
    path('Zaloguj', logowanie.zaloguj , name='zaloguj'),
    path('Rejestracja', logowanie.rejestr , name='rejestr'),
    path('zarezerwuj', rezerwacja.zarezerwuj , name='zarezerwuj'),
]